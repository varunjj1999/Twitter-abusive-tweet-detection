# Twitter-Abusive-Comments-Detection
This is machine learning based approach for detecting if the comments done on twitter are of abusive nature or not.
